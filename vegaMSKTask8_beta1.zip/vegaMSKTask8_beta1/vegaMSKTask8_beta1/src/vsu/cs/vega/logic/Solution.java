package vsu.cs.vega.logic;


public class Solution {


	public static int[][] TurnRight90(int[][] array) {
		int counter = 0;
		int ansver = 0;
		int max = 0;
		int namberAnswerArray = 0;
		int conkurent = 0;
		int P1 = 0;
		int P2 = 0;
		Rectangeles[] arrayForRectangles = new Rectangeles[array.length];
		int[][] ansverArray = new int[1][4];
//		List<Rectangles> list = new ArrayList<>();
		for (int i = 0; i < array.length; i++) {

			Point point1 = new Point(array[i][0], array[i][1]);

			Point point2 = new Point(array[i][2], array[i][3]);

			Rectangeles rectangles = new Rectangeles(point1, point2);

			arrayForRectangles[i] = rectangles;
		}

		for (int j = 0; j < arrayForRectangles.length; j++) {
			counter = 0;
			conkurent = 0;
			for (int g = 0; g < arrayForRectangles.length; g++) {
				if (rectangleInRectengleCheck(arrayForRectangles[j], arrayForRectangles[g])) {
					counter++;
					conkurent = j;
					System.out.println(counter);

				}
			}
			if (counter > max) {
				max = counter;
				namberAnswerArray = j;
			} else if (counter == max && P(arrayForRectangles[namberAnswerArray], arrayForRectangles[conkurent])) {
				namberAnswerArray = conkurent;
			}


		}
		return answerA(arrayForRectangles[namberAnswerArray]);


		//System.out.println(list.get(1));


	}public static boolean rectangleInRectengleCheck(Rectangeles rectangles, Rectangeles rectangles2) {

		return rectangles.point1.x >= rectangles2.point1.x && rectangles.point1.y >= rectangles2.point1.y
				&& rectangles.point2.x <= rectangles2.point2.x
				&& rectangles.point2.y <= rectangles2.point2.y;

	}public static boolean P (Rectangeles rectangles, Rectangeles rectangles2){
		int P1 =(rectangles.point2.x - rectangles.point1.x) * (rectangles.point2.y - rectangles.point1.y);
		int P2 = (rectangles2.point2.x - rectangles2.point1.x) * (rectangles2.point2.y * rectangles2.point1.y);
		return P2 > P1;
	} public static int [][] answerA (Rectangeles rectangles){
		int[][] ansverA = new int[1][4];

		ansverA[0][0] = rectangles.point1.x;
		ansverA[0][1] = rectangles.point1.y;
		ansverA[0][2] = rectangles.point2.x;
		ansverA[0][3] = rectangles.point2.y;
		return ansverA;

	}
}





